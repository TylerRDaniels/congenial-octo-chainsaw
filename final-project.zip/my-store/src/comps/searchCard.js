import React from "react"

export default function SearchCard(prop) {
    return (
        <tr className="totals" id="totals">
            <td colspan="1">
                <img className="" src="http://via.placeholder.com/120x100"/>
            </td>
            <td colspan="1">
                <h3>title</h3>
            </td>
            <td colspan="1">
                <p>desc</p>
            </td>
            <td className="total-values" id="totalValues">
                <p>price</p>
                <button className="btn btn-geg">add to cart</button>
            </td>
        </tr>
    )
}