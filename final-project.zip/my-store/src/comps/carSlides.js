import React from "react"
import GameCard from "./gameCard"

export default function CarSlides(prop) {

    const cards = prop.data.map((indCards) => {

        return (
            <GameCard 
                img={indCards.img}
                title={indCards.title}
            />
            
        )
    })

        return(

            <div className="card-cont">
                {cards}
            </div>
        )

}