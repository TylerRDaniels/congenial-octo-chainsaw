import React from "react"

export default function Footer() {
    return (
    <footer className="footer">
        <div className="container">
            <div className="row">
                <div className="col-md-6 d-flex justify-content-start">
                    <p className="colophon">site by Tyler Daniels &copy; 2022 <span className="colophon-span">all rights resureved</span></p>
                </div>
                <div className="col-md-6  d-flex justify-content-end">
                    <p>Back to <a href="#top">Top</a></p>
                </div>
            </div>
        </div>
    </footer>
    )
}