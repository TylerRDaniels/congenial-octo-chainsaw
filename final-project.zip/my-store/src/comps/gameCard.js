import React from "react";

export default function GameCard(prop) {
    return(
        <div className="col-md-3 game-card-item ">
            <a href="./single" class="game-card">
                <img src={prop.img} className="img-fluid game-car-img" />
                <h3 className="game-title">{prop.title}</h3>
                <a href="./cart" className="btn btn-geg">add to cart</a>  
            </a>
        </div>
    )
}