import React from "react";
import left from "../assets/left-arrow.png";
import right from "../assets/right-arrow.png";

import Catalog from "./catalog";
import Search from "./search";

export default function FrontPage(prop) {


    
    const [page, setPage] = React.useState(true)
    let cardLength = prop.cardData.length;

    let num = 0;

    // function addUp() {
    //     num + 1
    // }



    if (num >= cardLength) {
        num = 0;
    }


    console.log(cardLength)


    return (
        <main class="main">
        <div class="container">
        {page && <Catalog
                cardData={prop.cardData}
                imgHighlight={prop.imgHighlight}
                descHighlight={prop.descHighlight}
                titleHighlight={prop.titleHighlight}
            />}
        {!page && <Search/>}
        </div>
    </main>
    )
}