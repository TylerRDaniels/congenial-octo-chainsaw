import React from 'react';

export default function Single() {
    return (
    <main className="main-single">
        <section class="container">
            <div class="row row-single">
                <div class="col-md-6">
                    <h2 class="game-title">Lorem, ipsum.</h2>
                    <p class="game-desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque ratione quaerat, vero animi deleniti nemo facilis laudantium corrupti odit officiis sit molestiae, porro consequatur, aliquam nobis mollitia blanditiis distinctio necessitatibus sint similique velit modi impedit ducimus. Quibusdam at magni id autem, labore, ipsam doloribus libero inventore explicabo alias, perferendis aliquam!</p>
                    <p class="dev">Developer(s): DEV</p>
                    <p class="pub">Publisher: PUB</p>
                    
                </div>
                <div class="col-md-6">
                    <ul class="carousel-indicators">
                        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                    </ul>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                          <img src="http://via.placeholder.com/640x360" class=" img-fluid" alt="aditii" />
                        </div>
                        <div class="carousel-item">
                          <img src="http://via.placeholder.com/640x360" class=" img-fluid" alt="bloom" />
                        </div>
                        <div class="carousel-item">
                          <img src="http://via.placeholder.com/640x360" class=" img-fluid" alt="resturant" />
                        </div>
                        <div class="carousel-item">
                          <img src="http://via.placeholder.com/640x360" class=" img-fluid" alt="resturant" />
                        </div>
                    </div>
                    <div>
                      <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                      </a>
                      <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                      </a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 table-div">
                    <table class="table">
                        <tr class="table-headers">
                            <td class=" table-aline price">Price:</td>
                            <td class=" table-aline reagion">Reagion:</td>
                            <td class=" table-aline year">Year:</td>
                            <td class=" table-aline Rating">Rating:</td>
                        </tr>

                        <tr class="totals" id="totals">
                            <td  class=" table-aline price" colspan="1">
                                <p>20.00 (USD)</p>
                            </td>
                            <td class=" table-aline reagion" colspan="1">
                                <p>Worldwide</p>
                            </td>
                            <td class=" table-aline year" colspan="1"> 
                                <p>2021</p>
                            </td>
                            <td class=" table-aline Rating" colspan="1">
                                <p>M</p>
                            </td>
                        </tr>
                    </table>
                    <button class="btn btn-single btn-geg">Add To Cart</button>
                </div>
            </div>
        </section>
    </main>
    )
};