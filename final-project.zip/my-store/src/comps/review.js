import React from "react"


export default function Review(prop) {



    return (
        <div className="review">
            <h3 className="review-header">{prop.fName} {prop.lName}</h3>
            <p className="review-text">{prop.comment}</p>
        </div>
    )
}