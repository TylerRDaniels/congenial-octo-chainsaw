import React from "react"




export default function FormSection() {

    const [switchForm, setSwitchForm] = React.useState(['Ask a Question', "http://localhost:3001/api/question/create", "Question:"]);
    const [formData, setFormData] = React.useState({
        f_name:"",
        l_name:"",
        email:"",
        phone:"",
        comment: ""
    });

    function handleChange(event) {
        setFormData(prevFormData => {
            return {
                ...prevFormData,
                [event.target.name]: event.target.value
            }
        })
    }

    function toggleQuestion() {
        setSwitchForm(['Ask A Question', "http://localhost:3001/api/question/create", "Question:"])
        console.log(switchForm.length)
    } 

    function toggleReview() {
        setSwitchForm(['Write A Review', "http://localhost:3001/api/review/create", "Review:"])
        console.log(switchForm.length)
    } 

    function toggleApplication() {
        setSwitchForm(['Send An Aplication', "http://localhost:3001/api/app/create", "Tell Us About Yourself:"])
        console.log(switchForm.length)
    } 

    function handleSubmit(e) {
        e.preventDefault();
        const submitform = {...formData};

        fetch(switchForm[1], {
            method: 'POST',
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(submitform)
        })

        setFormData({
            f_name:"",
            l_name:"",
            email:"",
            phone:"",
            comment: ""
        })
    }
    
    
    return(
        <section className="app-job">
        <div className="col-md-12 d-flex justify-content-around">
            <button onClick={toggleQuestion} className="form-swapper btn btn-geg">Ask a Question</button>
            <button onClick={toggleReview} className="form-swapper btn btn-geg">Write a Review</button>
            <button onClick={toggleApplication} className="form-swapper btn btn-geg">Send an Application</button>
        </div>
        <div className="row">
            <div className="col-md-12 form-section">
                <form onSubmit={handleSubmit} className="about-form" >
                    <h2 className="main-header">{switchForm[0]}</h2>
                    <h3 className="main-h3">just contact us:</h3>
                    <input
                        type="text"
                        className="form-cont"
                        placeholder="First Name"
                        onChange={handleChange}
                        name="f_name"
                        value={formData.f_name}
                    />
                    <input
                        type="text"
                        className="form-cont"
                        placeholder="l_name"
                        onChange={handleChange}
                        name="l_name"
                        value={formData.l_name}
                    />
                    <input
                        type="Email"
                        className="form-cont"
                        placeholder="Email@email.com"
                        onChange={handleChange}
                        name="email"
                        value={formData.email}
                    />
                    <input
                        type="number"
                        className="form-cont"
                        placeholder="Phone Number"
                        onChange={handleChange}
                        name="phone"
                        value={formData.phone}
                    />
                    <lable for="textarea">{switchForm[2]}</lable>
                        <textarea 
                            name="comment" 
                            id="comment" 
                            value={formData.comment}
                            onChange={handleChange} 
                            cols="20" rows="5">
                        </textarea>

                    <button className="btn btn-geg">submit</button>
                </form>
            </div>
        </div>

    </section>

    )
}