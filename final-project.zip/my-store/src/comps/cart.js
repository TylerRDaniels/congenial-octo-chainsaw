import React from "react";

export default function Cart() {
    return(
        <main className="main-checkout">
            <section className="container">
                <div className="row">
                    <div className="col-md-12 checkout-div">
                        <table className="table">
                            <tr className="table-headers">
                                <td>product name</td>
                                <td>Price</td>
                                <td>Quantity</td>
                                <td>Subtotal</td>
                            </tr>

                            <tr className="totals" id="totals">
                                <td colspan="3">
                                    <p className="total-subtotal" id="totalSubtotal">subtotal</p>
                                    <p className="total-shipping" id="totalShipping">Shipping</p>
                                    <p className="total-tax" id="totalTax">tax</p>
                                    <p className="total-total" id="totalTotal">total</p>
                                </td>
                                <td className="total-values" id="totalValues">
                                    <p className="subtotal-value" id="subtotalValue"></p>
                                    <p className="shipping-value" id="shippingValue">6.00</p>
                                    <p className="tax-value" id="taxValue"></p>
                                    <p className="total-value">$<span id="totalValue"></span></p>
                                    <button className="btn btn-geg">Checkout</button>
                                
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </section>
        </main>
    )
}