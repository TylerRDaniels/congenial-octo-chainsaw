import React from "react"
import SearchCard from "./searchCard"


export default function Search(prop) {

    return (
        <div className="searchtable">
            <table className="table">
                    <tr className="table-headers">
                        <td>product image</td>
                        <td>product name</td>
                        <td>product description</td>
                        <td>Price</td>
                    </tr>
                    <SearchCard/>
                    <SearchCard/>
                    <SearchCard/>

                </table>
        </div>
    )
}