import React from "react"
import Review from "./review"
import FormSection from "./formSection"

export default function About(prop) {


    let randNum1 = Math.floor(Math.random() * prop.reviewData.length);
    let randNum2 = Math.floor(Math.random() * prop.reviewData.length);
    let randNum3 = Math.floor(Math.random() * prop.reviewData.length);

    const rCards = prop.reviewData.map((rCard) => {
        return (
            <Review
                fName={rCard.f_name}
                lName={rCard.l_name}
                comment={rCard.comment}
            />
        )
    })

    

    return(
        <main className="main-about">
        <div className="container">
            <section className="about">
                <div className="row">
                    <div className="col-md-12">
                        <div className="row">
                            <div className="col-md-12 push-up  d-flex justify-content-center ">
                                <div id="carouselExampleIndicators" className="carousel slide " data-ride="carousel">
                                    <ul className="carousel-indicators">
                                      <li data-target="#carouselExampleIndicators" data-slide-to="0" className="active"></li>
                                      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                                      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                                      <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                                    </ul>
                                    <div className="carousel-inner">
                                      <div className="carousel-item active">
                                        <img src="http://via.placeholder.com/640x360" className=" img-fluid" alt="aditii"/>
                                      </div>
                                      <div className="carousel-item">
                                        <img src="http://via.placeholder.com/640x360" className=" img-fluid" alt="bloom"/>
                                      </div>
                                      <div className="carousel-item">
                                        <img src="http://via.placeholder.com/640x360" className=" img-fluid" alt="resturant"/>
                                      </div>
                                      <div className="carousel-item">
                                        <img src="http://via.placeholder.com/640x360" className=" img-fluid" alt="resturant"/>
                                      </div>
                                    </div>
                                
                                    <a className="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                                      <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                                      <span className="sr-only">Previous</span>
                                    </a>
                                    <a className="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                                      <span className="carousel-control-next-icon" aria-hidden="true"></span>
                                      <span className="sr-only">Next</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div className="row  padding-rem">
                            <div className="col-md-8 width-ajust ">
                                <h2 className="main-header underline">About Us</h2>
                                <p className="main-text">Here at Golden Era Games, we are dedicated to the exploration, resturation, and reselling of games once thought of as out of date or garbage. Here our team of experts will guide every game or system that enters our store througe our rigerous cleaning, testing, and repair departments. We personaly assure you that a Golden Era system or game that enters your hands will look and play just like the day it was releaced* and is backed by our statisfation garonttea polocy.</p>
                                <p className="main-text">We here specilise in the deconstruction of all systems and games(excluding disc games) for the purpose of cleaning and resturation, if you need a system in need servicing we also can do this as well just look under the repair section of our catalog for more details we look forward to serving you.</p>
                                <p className="main-text">When you buy from our store; you support a small buisness that it looking at monoplolizing and turning into the amazon of game stores so help us support our dream of becomeing so powerfull we can go to mars by buying some of our merch lttstore.com jk this is not our merch this is the merch of the god of pc Gamers</p>
                            </div>
                            <div className="col-md-4 width-ajust ">
                                <h2 className="main-header underline">Our Reviews</h2>
                                <div className="review">
                                    {rCards[randNum1]}
                                    {rCards[randNum2]}
                                    {rCards[randNum3]}

                                </div>                        
                            </div>
                        </div>
                        
                    </div>
                </div>
            </section>
            <section className="nav-section">
                <div className="row">
                    <div className="col-md-12 ">
                        <nav className="main-nav">
                            <a href="./" className="nav-item btn btn-geg">Our Catalog</a>
                            <a href="" className="nav-item btn btn-geg">New Releaces</a>
                        </nav>
                        <nav className="main-nav">
                            <a href="" className="nav-item btn btn-geg">Under 10$</a>
                            <a href="" className="nav-item btn btn-geg">Under 5$</a>
                        </nav>
                    </div>
                </div>
            </section>
            <FormSection/>
        </div>
    </main>
    )
}