import React from "react"
import GameCard from "./gameCard";
import CarSlides from "./carSlides"

export default function Catalog(prop) {
    return(
        <div>
                        <section class="top-catalog ">
                <div class="row">
                    <div class="col-md-12 underline">
                        <h2 class="highlight-header">Game Highlight</h2>
                    </div>
                    <div class="col-md-4">
                        <h3 class="game-name">{prop.titleHighlight}</h3>
                        <p class="game-desc">{prop.descHighlight}</p>
                    </div>
                    <div class="col-md-8 ">
                        <a href="" class="game-imgs">
                            <img src={prop.imgHighlight} class="highlight-img img-fluid" alt=""/>
                        </a>
                    </div>
                </div>
            </section>
            <section class="main-catalog">
                <div class="row">
                    <div class="col-md-2">
                        <form class="Make" action="">
                            <div class="title-div title-underline">
                                <h2 class="form-title ">Make</h2>
                                <a href=""><img class=" img-fluid" src="css/media/downarrow.png" alt=""/></a>
                            </div>

                            <div class="input d-flex">
                                <div>
                                    <input type="checkbox" name="PlayStation" id=""/>
                                    <label for="PlayStation">PlayStation</label>
                                </div>
                                <div>
                                    <input type="checkbox" name="Xbox" id=""/>
                                    <label for="Xbox">Xbox</label>                              
                                </div>
                                <div>
                                    <input type="checkbox" name="Nintentdo" id=""/>
                                    <label for="Nintendo">Nintendo</label>   
                                </div>
                            </div>  
                        
                        </form>
                        <form class="System" action="">
                            <div class="title-div title-underline">
                                <h2 class="form-title ">Systems</h2>
                                <a href=""><img class=" img-fluid" src="css/media/downarrow.png" alt=""/></a>
                            </div>
                            <div class="input d-flex">
                                <div>
                                    <input type="checkbox" name="PlayStation" id=""/>
                                    <label for="PlayStation">PlayStation</label>
                                </div>
                                <div>
                                    <input type="checkbox" name="Xbox" id=""/>
                                    <label for="Xbox">Xbox</label>                              
                                </div>
                                <div>
                                    <input type="checkbox" name="Nintentdo" id=""/>
                                    <label for="Nintendo">Nintendo</label>   
                                </div>
                            </div>  

                        </form>
                        <form class="Price" action="">
                            <div class="title-div title-underline">
                                <h2 class="form-title">Price</h2>
                                <a href=""><img class=" img-fluid" src="css/media/downarrow.png" alt=""/></a>
                            </div>
                            <div class="d-flex justify-content-between">
                                <input class="num-inpt" type="number" name="min" id="" placeholder="min"/>
                                <p class="cross">X</p>
                                <input class="num-inpt" type="number" name="Max" id="" placeholder="max"/>

                            </div>
                        </form>
                    </div>
                    <div class="col-md-10">
                        <div class="col-md-12 underline">
                            <h2 class="highlight-header">All Games</h2>
                        </div>
                        <div class="col-md-12 game-div">

                                <button class="btn btn-geg" type="button" data-target="#newReleces" data-slide="prev"></button>
                                <div id="newReleces" class="carousel slide game-div" data-ride="carousel">
                                    
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <CarSlides 
                                                data={prop.cardData}/>
                                        </div>
                                        <div class="carousel-item">
                                            <CarSlides 
                                                data={prop.cardData}/>
                                        </div>
                                        {/* <div class="carousel-item">
                                            <CarSlides 
                                                data={prop.cardData}/>
                                        </div>  */}
                                    </div>
                                    
                                </div>    
                                <button class="btn btn-geg" type="button" data-target="#newReleces" data-slide="next"></button>
                        </div>
    
                        <div class="col-md-12 underline">
                            <h2 class="highlight-header">Under 10$</h2>
                        </div>
                        <div class="col-md-12 game-div">
                            <button class="btn btn-geg" type="button" data-target="#underTen" data-slide="prev"></button>
                                    <div id="underTen" class="carousel slide game-div" data-ride="carousel">
                                        
                                        <div class="carousel-inner">
                                            <div class="carousel-item active">
                                                <div className="card-cont d-flex"></div>
                                            </div>
                                            <div class="carousel-item">
                                                <div className="card-cont d-flex"></div>
                                            </div>
                                            <div class="carousel-item">
                                                <div className="card-cont d-flex"></div>
                                            </div> 
                                        </div>
                                        
                                    </div>    
                            <button class="btn btn-geg" type="button" data-target="#underTen" data-slide="next"></button>
                        </div>
    
    
                        <div class="col-md-12 underline">
                            <h2 class="highlight-header">Under 5$</h2>
                        </div>
                        <div class="col-md-12 game-div">
                            <button class="btn btn-geg" type="button" data-target="#underFive" data-slide="prev"></button>
                                    <div id="underFive" class="carousel slide game-div" data-ride="carousel">
                                        
                                        <div class="carousel-inner">
                                            <div class="carousel-item active">
                                                <div className="card-cont d-flex"></div>
                                            </div>
                                            <div class="carousel-item">
                                                <div className="card-cont d-flex"></div>
                                            </div>
                                            <div class="carousel-item">
                                                <div className="card-cont d-flex"></div>
                                            </div> 
                                        </div>
                                        
                                    </div>    
                            <button class="btn btn-geg" type="button" data-target="#underFive" data-slide="next"></button>
                        </div>

                        <div class="col-md-12 underline">
                            <h2 class="highlight-header">Systems</h2>
                        </div>
                        <div class="col-md-12 game-div">
                            <button class="btn btn-geg" type="button" data-target="#system" data-slide="prev"></button>
                                    <div id="system" class="carousel slide game-div" data-ride="carousel">
                                        
                                        <div class="carousel-inner">
                                            <div class="carousel-item active">
                                                <div className="card-cont d-flex"> </div>
                                            </div>
                                            <div class="carousel-item">
                                                <div className="card-cont d-flex"></div>
                                            </div>
                                            <div class="carousel-item">
                                                <div className="card-cont d-flex"></div>
                                            </div> 
                                        </div>
                                        
                                    </div>    
                            <button class="btn btn-geg" type="button" data-target="#system" data-slide="next"></button>
                        </div>
                    </div>

                </div>

            </section>
        </div>
    )
}