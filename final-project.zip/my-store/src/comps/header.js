import React from "react"

//socail images
import twitter from "../assets/twitter.png"
import facebook from "../assets/facebook2.png"
import insta from "../assets/instagram.png"
import yt from "../assets/youtube.png"

export default function Header(prop) {
    return (
        <header className="header ">
        <div className="container">
            <div className="row">

            </div>
            <div className="row header-row">
                <div className="col-md-6 header-div">
                    <div className="header-text-div">
                        <h1 className="header-h1">Golden Era Games</h1>
                        <h2 className="header-h2">www.geg.com</h2>
                    </div>
                </div>
                <div className="col-md-6 nav-div">
                    <div className="social-cont">
                        <a href="www.twitter.com"><img src={twitter} alt="twitter"/></a>
                        <a href="www.facebook.com"><img src={facebook} alt="twitter"/></a>
                        <a href="www.instagram.com"><img src={insta} alt="twitter"/></a>
                        <a href="www.youtube.com"><img className="yt" src={yt} alt="twitter"/></a>
                    </div>
                    <nav className="header-nav">
                        <input className="search" placeholder="search" type="text"/>
                        <a href="/about" className="header-btn btn btn-geg">About Us</a>
                        <a href="/" className="header-btn btn btn-geg">Catalog</a>
                        <a href="/cart" className="header-btn btn btn-geg">Your Cart</a>
                    </nav>
                </div>
            </div>
            <div className="row">
                <div className="col-md-12 make-nav">
                    <div className="Nintendo">
                        <a href="" className="Nintendo">Nintendo</a>
                    </div>
                    <div className="PlayStation">
                        <a href="" className="PlayStation">PlayStation</a>
                    </div>
                    <div className="Xbox">
                        <a href="" className="Xbox">Xbox</a>
                    </div>
                </div>
            </div>
        </div>
    </header>
    )
}