//import dependencies
import React from "react";
import './App.css';
import { Routes, Route } from 'react-router-dom';
//constant componants
import Header from "./comps/header.js";
import Footer from "./comps/footer.js";
//main comps
import About from "./comps/about.js"
import Single from './comps/single-game';
import FrontPage from './comps/front-page';
import Cart from "./comps/cart";


function App() {

  const [games, setGames] = React.useState([]);
  const [reviews, setReviews] = React.useState([]);
  const [randGame, setRandGame] = React.useState({});
 

  console.log(randGame)

  React.useEffect(()=> {
      //  console.log("effect ran")
      fetch("http://localhost:3001/api/games")
          .then(res => res.json())
          .then(data => {
            setGames(data)
            setRandGame(data[Math.floor(Math.random() * data.length)])
          });

      fetch("http://localhost:3001/api/review")
          .then(res => res.json())
          .then(data => setReviews(data))
  }, []);

  return (
    <div className="App">
      <Header/>
        <Routes>
          <Route path="/" element={<FrontPage 
            cardData={games}
            imgHighlight={randGame.img}
            descHighlight={randGame.gameDesc}
            titleHighlight={randGame.title}
          />} />
          <Route path="/cart" element={<Cart/>} />
          <Route path="/about" element={<About
            reviewData={reviews}
          />}/>
          <Route path="/single" element={<Single/>} /> 
        </Routes>
      <Footer/>
    </div>
  );
}

export default App;
